(function(global){
	
	var start = function(){
		var pageone = new BX.PageOne;
		var pagetwo = new BX.PageTwo;
		var pagethree = new BX.PageThree;
		var pageFour = new BX.PageFour;
	}	
	BX.start = start;
	
}(BX));

BX.start();