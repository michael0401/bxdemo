/* ===================================================
 * design.js v0.01
 * https://github.com/rranauro/boxspringjs
 * ===================================================
 * Copyright 2013 Incite Advisors, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

/*jslint newcap: false, node: true, vars: true, white: true, nomen: true  */
/*global _: true, Boxspring: true, emit: true, sum: true */

(function(global) {
	"use strict";

	var templateDesign = function() {
		return({
			'language': 'javascript',
			'updates': {},
			'views': {
				'lib': {}		
			},
			'shows': {},
			'lists': {}
		});		
	};
	
	// What it does: Templated data structure for a CouchDB design document; 
	// map functions of defaultDesign are capable of also running in Nodejs.
	var defaultDesign = function () {
		// Note: CouchdDB defines toJSON globally to its environment, this won't be there on the server
		var toJSON = function(o) {
			return(JSON.stringify(o));
		};
		// Note: This code may run on the server, where exports may not be defined.
		if (typeof exports === 'undefined') {
			var exports = {};
		}

		return({
			'language': 'javascript',
			'updates': {
				// want to force all my documents to have a created_at, size, last_updated;
				// able to pass in additional key-values to the in-place method
				// applications should use this method to enforce their 'type'-ing
				"in-place" : function (doc, req) {
					var i;

					if (req && req.query) {
						for (i in req.query) {
							if (req.query.hasOwnProperty(i)) {
								doc[i] = req.query[i];
							}
						}		
					}
					doc['last-updated'] = Date();
					doc['in-place-succeeded'] = true;
					doc.size = JSON.stringify(doc).length;
					return [doc, toJSON(doc) ];
				}				
			},
			'views': {
				'lib': {},
				'Index': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'reduce': function(keys, values, rereduce) {
						if (rereduce) {
							return sum(values);
						}
						return values.length;
					},
					'header': {
						'sortColumn': '_id',
						'keys': ['_id'],
						'columns': ['_id', 'doc']
					}
				}			
			},
			'shows': {},
			'lists': {}
		});
	};
	
	var design = function (name, custom) {
		// extend this object with the db methods from the caller
		var ddoc = {}
		, maker
		, views 
		, that = _.extend({}, this.doc());
		
		if (name && _.isFunction(name)) {
			custom = name;
			name = this._design;
		} else if (!name) {
			name = this._design;
		} else {
			that._design = name;
		}

		// update the url for this design object
		if (name.split('/').length > 1) {
			that.url([ that.url(), name ].join('/'));
		} else {
			that.url([ that.url(), '_design', name ].join('/'));			
		}

		var configure = function (target, maker) {
			// update the document object with 
			target.headers.set( 'X-Couch-Full-Commit', false );
			target.maker = maker;
			target.views = maker().views;
			target.types = maker() && maker().types;
			target.formats = target.views && target.views.lib && target.views.lib.formats;			
		};
		// configure the object with its maker function: custom or owner or default
		configure(that, (custom || this.maker || defaultDesign));

		var extend = function(section, name, object) {
			var reduceFunc = object && object.reduce;
			
			if (!ddoc[section]) {
				ddoc[section] = {};
			}
			
			if (!ddoc[section][name]) {
				ddoc[section][name] = {};
			}
			
			if (section === 'views' && (object && object.map)) {
				if (typeof object.map === 'function') {
					ddoc.views[name].map = _.Serialize(object.map);
				}
				if (reduceFunc) {
					if (typeof reduceFunc === 'function') {
						ddoc.views[name].reduce = _.Serialize(reduceFunc);
					} else {
						ddoc.views[name].reduce = reduceFunc;
					}
				} else {
					ddoc.views[name].reduce = '_count';
				}
				
				ddoc.views[name]['header'] = (object && object.header) 
															|| { 'keys': [], 'columns': [] };												
			} else if (section === 'views' && name === 'lib') {
				_.each(_.keys(object), function(key) {
					// Don't serialize .lib functions. they are not used on the server side
					// and so won't be saved to the design document anyways; When the client 
					// fetches a design document we just want the object [Function]
					ddoc.views.lib[key] = object[key];
				});
			}	
		};
		that.extend = extend;
				
		// fetches the design document from the server, and updates the 'maker' function
		var fetch = function(callback) {
			var design = this
			, originalMaker = design.maker;
			
			this.read(function(err, response) {
				var template = templateDesign();
				if (err) {
					return(err, response.body);
				}
				
				// upon reading from the server, the new maker function extends the original
				// with views/shows/lists residing in the design document on the server;
				_.each(_.keys(template), function(key) {
					template[key] = _.extend({}, response.data[key], originalMaker()[key]);
				});

				design.maker = function() {
					return template;
				};
				// update the configuration of this object;
				configure(design, design.maker);
				
				if (_.isFunction(callback)) {
					callback(err, {'ok': true, 'message': 'Fetched design document.'});
				}
			});
			return this;
		};
		that.fetch = fetch;

		// set the language
		ddoc.language = 'javascript';

		// add application views
		ddoc.views = {};	
		_.each(that.views, function (views, name) { 
			var mapFunc = views.map
				, reduceFunc = views && views.reduce
				, header = views && views.header;
				
			if (name !== 'lib' && !mapFunc) {
				throw new Error ('design(): Named view is not provided by Maker function - '+name);
			}
			extend.call(that, 'views', name, views);
		});

		// 'updates', 'shows', 'lists' 
		['updates', 'shows', 'lists'].forEach(function(item) {
			ddoc[item] = {};
			_.each(that.maker()[item] || [], function (toString, name) { 
				ddoc[item][name] = {};
				ddoc[item][name] = _.Serialize(toString);
			});
		});

		// add the 'types' structure, if it exists
		if (that.maker().hasOwnProperty('types')) {
			ddoc.types = that.maker().types;
		}
		
		// add validate_doc_update, if it exists
		if (that.maker().hasOwnProperty('validate_doc_update')) {
			ddoc.validate_doc_update = _.Serialize(that.maker().validate_doc_update);
		}
		
		// finally update the design document content using method
		that.source(ddoc);

		// if there is no default _view for this design, then use the first view supplied
		if (!that['_view']) {
			that['_view'] = '_view/' + _.keys(that.views)[0];
		}
		
		// 'name' argument is the name of the '_update/' routine
		var updateDoc = function (name) {
			var owner = this
			, doc = this.doc();
			
			if (!name) {
				name = owner._update;
			}

			// update the url for this update object
			if (name.split('/').length > 1) {
				doc.url([ owner.url(), name ].join('/'));
			} else {
				doc.url([ owner.url(), '_update', name ].join('/'));			
			}
			
			// make this the default
			doc.headers.set('X-Couch-Full-Commit', false);		

			// this update takes advantage of CouchDB 'updates' handlers. 
			// The design document function specified in '_update' will execute on 
			// the server, saving the round-trip to the client a enforcing consistent
			// attributing of the documents on the server for a corpus.
			var commit = function (targetId, properties, handler) {
				// targetId and properties are 'optional'
				handler = _.toArray(arguments)[arguments.length-1];
				
				if (_.isFunction(targetId)) {
					properties = {};
					targetId = undefined;
				} else if (_.isString(targetId) && _.isFunction(properties)) {
					properties = {};
				} else if (_.isObject(targetId) && _.iFunction(properties)) {
					properties = targetId;
					targetId = undefined;
				}
				
				// install the new properites in the doc to be updated
				if (_.keys(properties)) {
					doc.options.update(properties);
				}
				
				// update the url, if needed
				if (targetId) {
					doc.url([ this.url(), targetId ].join('/'));					
				} else {
					// if there is no id, then the method is POST, not PUT
					doc.set('_method', 'POST');
				}
				
				doc.save(handler);
				return this;			
			};
			doc.update = commit;
			return doc;		
		};
		that.updateDoc = updateDoc;
		return that;	
	};
	global.design = design;
	
}(Boxspring));
