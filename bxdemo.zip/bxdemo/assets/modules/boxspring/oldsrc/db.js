/* ===================================================
 * db.js v0.01
 * https://github.com/rranauro/boxspringjs
 * ===================================================
 * Copyright 2013 Incite Advisors, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

/*jslint newcap: false, node: true, vars: true, white: true, nomen: true  */
/*global _: true, Boxspring: true, Backbone: true */

if (typeof _ === 'undefined') {
	if (typeof exports !== 'undefined') {
		_ = require('underscore');
	} else if (typeof _ === 'undefined') {
		throw new Error('Boxspring.js requires Underscore.js');
	}
}

if (typeof Boxspring === 'undefined') {
	Boxspring = {};	
}

(function(global) {
	"use strict";
	
	var db = function (options) {
		var that = _.extend({}, _.hash(options), this);
				
		// allow either 'name' or {options} but not both arguments
		if (_.isString(options)) {
			options = { 'db_name': options };
		} else if (!options) {
			options = {};
		}
		
		var queryHTTP = function (options, callback) {
			var local = this;
			this.HTTP({
				'path': ((options && options.url) || '') + _.formatQuery((options && options.query) || {}),
				'method': ((options && options.method) || 'GET'),
				'body': ((options && options.body) || {}),
				'auth': (options && options.auth) || this.auth,
				'headers': ((options && options.headers) || this.headers.post())
			}, function (err, res) {
				if ((callback && typeof callback) === 'function') {
					callback.call(local, err, res);
				}
			});
		};
		that.queryHTTP = queryHTTP;
		
		var heartbeat = function (handler) {	
			this.queryHTTP({ 'url': '' }, handler);
			return this;
		};
		that.heartbeat = heartbeat;
		
		var session = function (handler) {
			this.queryHTTP({'url': '/_session'}, handler);
			return this;
		};
		that.session = session;

		var all_dbs = function (handler) {
			this.queryHTTP({'url': '/_all_dbs'}, handler);
			return this;
		};
		that.all_dbs = all_dbs;
		
		var uuids = function(count, handler) {
			if (_.isFunction(count)) {
				handler = count;
				count = 1;
			}
			this.queryHTTP({
				'url': '/_uuids',
				'query': { 'count': count }}, handler);
			return this;
		};
		that.uuids = uuids;
		
		// What it does: attempts to login the user to this database. 
		var login = function (handler, encode) {
			var local = this;
			
			this.queryHTTP({
				'url': '/_session',
				'method': 'POST',
				'headers': { 'Content-Type': 'application/x-www-form-urlencoded' },
				'body': _.formatQuery(this.auth).slice(1) }, function(err, response) {
					if (err) {
						return handler(err, response);
					}
					local.session(handler);
				});
		};
		that.login = login;
		
		var logout = function(handler) {
			this.queryHTTP({
				'url': '/_session',
				'method': 'DELETE'
			}, handler);
			return this;
		};
		that.logout = logout;
		
		// replicate the source database to the target; arguments are Boxspring.js database
		// document objects
		var replicate = function(source, target) {
			var doc = this.doc('_replicate')
			, sourceURL = _.urlParse(source.url())
			, sourceAuth = this.get('auth').name + ':' + source.get('auth').password
			, targetURL = _.urlParse(target.url())
			, targetAuth = target.get('auth').name + ':' + target.get('auth').password
			
			doc.set('_method', 'POST');
			console.log(_.urlFormat(_.extend(_.urlParse(this.urlRoot), { 
				'auth': sourceAuth,
				'path': this.url() })));
		};
		that.replicate = replicate;
		return that;
	};

	global.createdb = function(options) {
		var object = db.call(this, options)
		, use = function (urlRoot) {
			var new_db = _.extend({
				// expose these to the interface of this object
				'db_name': this.get('db_name'),
				'maker': this.get('maker'),
				'_design': this.get('_design') || '_design/default',
				'_view': this.get('_view') || '_view/default',
				'_update': this.get('_update') || '_update/default',
				'auth': this.get('auth') || {'name': '', 'password': ''},
				// if app does not supply a urlRoot, or doesn't provie a protocol, use localhost;
				'urlRoot': (!urlRoot || urlRoot === '127.0.0.1' || urlRoot === 'localhost') 
					? 'http://localhost:5984'
					: urlRoot
			}, object);
			
			
						
			// be forgiving, prepend the reserved words _design, _view, _update if needed
			['_design', '_view', '_update'].forEach(function(option) {
				if (new_db[option] && new_db[option].indexOf(option) === -1) {
					new_db[option] = [ option, new_db[option] ].join('/');
				}
			});
			// all subsequent HTTP calls will use the supplied credentials.
			new_db.HTTP = _.server('server', 
				_.urlParse([new_db.urlRoot, new_db.db_name].join('/')), this.get('auth')).get;
			return new_db.doc();
		};
		object.use = use;
		return object;
	};
}(Boxspring));
