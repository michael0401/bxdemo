/* ===================================================
 * rows.js v0.01
 * https://github.com/rranauro/boxspringjs
 * ===================================================
 * Copyright 2013 Incite Advisors, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

/*jslint newcap: false, node: true, vars: true, white: true, nomen: true  */
/*global _: true, Boxspring: true */

(function(global) {
	"use strict";
	
	var Rows = function (response) {		
		// Object for adding methods and data to rows of a 
		// response data object based on information about the design
		var design = this
		, ddoc = this.views
		, view =  this._view.split('/').length > 1
			? this._view.split('/')[1]
			: this._view
		, that = _.extend({}, response)
		, thisSelected = [];
		
		if (ddoc && view && ddoc[view] && ddoc[view]['header']) {
			that.sortColumn = ddoc[view]['header'].sortColumn || []; 
			that.columns = ddoc[view]['header'].columns || [];
			that.keys = ddoc[view]['header'].keys || [];
		} else {
			that.columns = [];
			that.keys = [];
		}

		// initialize 'displayColumns'.
		that.displayColumns = that.columns;

		// initialize the 'cell' object methods to allow typing and formatting individual cells
		that.cell = this.cell(design && design.types, design && design.formats);
		
		// wrap each row in a row object and make the response object available to all methods
		if (response) {
			that.response = response;
			response.body.rows = _.map (response.body.rows, function (row) {
				return design.row(that, row);
			});			
		}
		
		// HELPERS
		// allow the caller to iterate using each or map;
		var rows = function () {
			return this.body.rows;
		};
		that.rows = rows;
		
		var offset = function () {
			return this.body.offset;
		};
		that.offset = offset;
		
		var first = function () {
			return this.body && this.body.rows[0];
		};
		that.first = first;

		var last = function () {
			return this.body.rows[this.body.rows.length-1];
		};
		that.last = last;
		
		// return the row record at the given index. return the first or last if no index or the
		// index given is out of bounds.
		var getRow = function(index) {
			if (index > -1) {
				if (index < this.getLength()) {
					return this.body.rows[index];
				} 
				return this.last();
			}
			return this.first(); 
		};
		that.getRow = getRow;
		
		var total_rows = function () {
			return (this.body && this.body.total_rows) || 0;
		};
		that.total_rows = total_rows;
		
		var getLength = function () {
			return this.body.rows.length;
		};
		that.getLength = getLength;
		
		// What it does: returns the list of unique values for a key 'facet' over the set of rows
		var facets = function (name) {	
			return _.compact(_.uniq(_.sortBy(_.map(this.rows(), function(row) {
			//	console.log('selecting', name, row.select(name));
				var s = row.select(name);
				return (s && s.toString());
			}), _.item)), true);
		};
		that.facets = facets;
		
		// What this does: runs the filter through each row to produce an array of indexes of rows that pass
		// array is passed to getSelected to return a result object with rows that pass.
		var filter = function(object) {
			return (this.getSelected(_.reduce(this.rows(), function(result, row, index) {
				if (row.filter(object)) {
					result.push(index);
				}
				return result;
			}, [])));
		};
		that.filter = filter;
		
		// setter/getter for indicating a list of rows is 'selected'
		var getSelected = function (selectedRows) {
			var selectedRowData = _.clone(response)
			, local = this;
			
			// if some have been marked selected, map those rows; else just return everything
			if (selectedRows.length > 0) {
				selectedRowData.body.rows = _.map(selectedRows, function(index) {
					return local.getRow(index);
				});
			}
			// make a new rows object from this data and return it;
			return Rows.call(design, selectedRowData);
		};
		that.getSelected = getSelected;

		var sortByValue = function (iterator) {
			var compare = iterator || function (row) { return -(row.getValue()); };

			// for each pages, sort
			return this.getSelected(_.sortBy(this.rows(), compare));
		};
		that.sortByValue = sortByValue;

		// helper: called on a 'reduce': true view to get the first and last keys of an
		// index. knows nothing about the type, so range can be anything.
		var range = function () {
			return({ 'start': this.first().getKey(), 'end': this.last().getKey() });
		};
		that.range = range;

		var getSortColumn = function (c) {
			if (c) {
				this.sortColumn = c;
			}
			return this.sortColumn;
		};
		that.getSortColumn = getSortColumn;

		// setter/getter for modifying the list of columns to display;
		var getDisplayColumns = function(d) {
			if (d) {
				this.displayColumns = _.isArray(d) && d;
			}
			return (((this.displayColumns).length && this.displayColumns) || this.columns);
		};
		that.getDisplayColumns = getDisplayColumns;
		
		var setDisplayColumns = function(access) {
			return this.getDisplayColumns(this.calcDisplayColumns(access));
		};
		that.setDisplayColumns = setDisplayColumns;
		
		// What it does: given a source ('doc', 'value'), iterate over a set of rows and calculate
		// the set of properties contained in the rows
		var calcDisplayColumns = function(access) {
			var columns = {};
			
			access = access || function(row) {
				// the 'map-reduce' value is the priority if there are over lapping keys for a row
				return _.extend({}, 
					row.doc && row.doc.resource || {},
					row.doc || {}, 
					row.value || {});
			}

			_.each(this.rows(), function(row) {
				_.each(_.keys(access(row)), function(key) {
					columns[key] = true;
				});
			});
			return _.keys(columns);
		};
		that.calcDisplayColumns = calcDisplayColumns;

		// What it does: returns the index of the column requested, 
		// or 'sortColumn', or 0 if not found
		var column2Index = function (c) {
			var column = c || this.getSortColumn()
			, activeColumns = this.columns2Display || this.columns;
			return	(_.found(activeColumns, column) ?
						_.fetch(activeColumns, column) : 0);
		};
		that.column2Index = column2Index;

		// What it does: converts an integer index into the column list and 
		// returns the name of the column
		var index2Column = function (i) {
			var index = _.isNumber(i) ? i : column2Index();
			return this.displayColumns[index] || this.columns[index];
		};
		that.index2Column = index2Column;

		// What this does: use the names of the columns to determine the 'type' 
		// of the column and sort based on that type
		var sortByColumn = function (reverse) {
			var direction = (reverse) ? -1 : 1
			, local = this;

			this.displayColumns = _.sortBy(this.columns, function (x) {

				if (_.isNumber(x) || !_.isNaN(_.toInt(x))) {
					return (_.toInt(x) * direction);
				}
				// else returns the position in the array
				return (_.fetch(local.columns, x) * direction);
			});

			return this;
		};
		that.sortByColumn = sortByColumn;
		return that;
	};
	global.rows = Rows;
	
}(Boxspring));
