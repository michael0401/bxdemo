/* ===================================================
 * display.js v0.01
 * https://github.com/rranauro/boxspringjs
 * ===================================================
 * Copyright 2013 Incite Advisors, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

/*jslint newcap: false, node: true, vars: true, white: true, nomen: true  */
/*global _: true, bx: true */


(function(global) {
	"use strict";
		
	// What it does: Query / Result Objects
	var model = function (query) {
		

	global.model = model;
}(boxspring));	
		


(function(global) {
	"use strict";
	var display;
	
	if (typeof exports !== 'undefined') {
		display = exports;
	} else {
		display = global.display = {};
	}
	
	// What it does: Query / Result Objects
	display.construct = function (db, options, tags) {
		var initialOptions = _.extend({}, options || {}, tags || {})
		, local = _.extend(this, bx.Events());
		
		// create an event context private to this object
		// when an event in this context, trigger the same event in callers context
		this.events = bx.Events({}, this, _.values(tags));
		
		_.extend(this, bx.Lookup.Hash(_.defaults(initialOptions, {
			// query parameters
			'reduce': false,
			'limit': 100,
			'startkey': undefined,
			'endkey': undefined,
			'group_level': undefined,
			'descending': false,
			'key': undefined,
			'keys': undefined,
			'filter': {},
			'pivot': false,
			'display': false,
			'vis': 'table',
			// event tags
			'onDisplay':'#onDisplay', 
			'onResult':'onResult', 
			'onMoreData':'onMoreData',
			'onSelection': 'onSelection',
			'onPagination': 'onPagination',
			'showTitle': '#showTitle',
			'showPage': '#showPage',
			'showTotalPages': '#showTotalPages',
			'showRow': '#showRow',
			'showLastRow': '#showLastRow',
			'showTotalRows': '#showTotalRows',
			'onDisplayStart': 'onDisplayStart',
			'onDisplayEnd': 'onDisplayEnd',
			// system parameters
			'system': _.defaults((initialOptions && initialOptions.system) || {}, {
				'asynch': false,
				'cache_size': 10,
				'page_size': 100
			})
		})));
		this.db = db;
		this.selected = bx.Lookup.Hash();
	
		// if we're inthe browser, set pagination using
		// the built-in onResult tag for updating the next/prev
		if (_.browser()) {
			bx.pagination(this, this.post());
		}
		
		// onDisplay is triggered when the first chunk of data is ready from the server
		this.events.on(this.get('onDisplay'), function (result, onPagination) {
			var onSelectionId = _.uniqueId('onSelection-');
			// executes the google-vis to render the table to the onDisplay div
			// onSelection gives a tag to the vis to call when rows are selected
			// only trigger if query.display is true

			if (local.get('display') === true) {
				if (onPagination) {
					local.query.events.trigger(local.get('onPagination'));
				} else {
					var renderOptions = {
						'query': result.query,
						'result': result,
						'tags': result.query.post(),
						'onSelection': onSelectionId
					};
					// install the selection handler
					local.events.on(onSelectionId, function (tableData) {
						// update the hash of filtered items
						local.events.trigger(local.get('onSelection'),
							local.handleSelections(tableData));
					});
					// fire the meters, the render, and make sure listeners are evented
					local.events.trigger(local.get('onDisplayStart'));				
					bx.renderLib('google').display(renderOptions);
					local.events.trigger(local.get('onDisplayEnd'));					
				}
			}
		});
		// keep feeding the vis with more data
		this.events.on('onMoreData', function (data) {			
			local.events.trigger(local.get('onDisplay'), data.unPaginate());
		});
	};
	
	// What it does: maintains a hash of selected keys
	var handleSelections = function (tableData) {
		var local = this
		, that = {}
		, pageInfo = tableData.data.result.pageInfo();				
		
		that.query = this;
		that.reference = tableData.data;
		that.selectedKeys = tableData.selectedKeys;
		that.rowIndices = tableData.rowIndices;

		// remove any previous selections on this page before starting
		// hash is as follows: hash[id] = page#
		if (local.selected) {
			local.selected.each(function(pageNo, id) {
				if (pageNo === (pageInfo && pageInfo.page)) {
					local.selected.remove(id);
				}
			});
		}
		// install these keys into the 'selected' hash, associated with this page
		that.selectedKeys.forEach(function(key) {
			local.selected.store(key, pageInfo.page);
		});
		
		that.listEnd = function () {
			var startkey
			, endkey;
			
			if (this.selectedKeys.length > 0) {
				startkey = this.selectedKeys[this.selectedKeys.length-1];
				endkey = this.selectedKeys[this.selectedKeys.length-1].concat({});
			}
			
			return({
				'reduce': false,
				'startkey': _.map(startkey, function(x) { 
					return x.toString(); }),
				'endkey': _.map(endkey, function(x) { 
					return (_.isObject(x) ? {} : x.toString()); })
			});			
		};
		return that;
	};
	query.handleSelections = handleSelections;

	// What it does: refreshes the display. if query is a 'pivot', it recalculates the result
	// but, only if the application does not say 'displayOnly'
	var refresh = function () {
		this.events.trigger(this.get('onDisplay'), this.result);
		return this;
	};
	query.refresh = refresh;
	
	var result = function () {					
		var queryPages = { 'pages': [] }
		, current_chunk = 0
		, current_page = 0;	// zero-based

		// wraps the response.data object with some helper methods
		var data = function (response) {
			// helpers						
			response.query = query;	// owner
			response.rid = _.uniqueId('result-');
			/*jslint unparam: true */
			response.visibleRows = _.map(response.each(), function(v, i) { 
				return response.offset() + i; 
			});
			
			var pages = function () {
				return _.clone(queryPages.pages);
			};
			response.pages = pages;

			var page = function () {
				if (current_chunk > 0) {
					// does not create a new 'pages', returns to tha caller the cached
					// response object from the server
					return queryPages.pages[current_chunk];						
				}
				return this;
			};
			response.page = page;

			// return a paginated query as though it was captured in one block 
			var unPaginate = function () {
				var allPages = { 'data': {
					'rows': []	
				}};

				// copy the first page as template to allPages
				allPages = _.extend({}, this.pages()[0], allPages);
				this.pages().forEach(function(page) {
					allPages.data.rows = 
						allPages.data.rows.concat(page.data.rows || []);
				});
				return allPages;
			};
			response.unPaginate = unPaginate;

			var pageInfo = function () {
				var local = this;
				
				//console.log('pageInfo completed', local.total_rows, local.offset, local.rows.length);
				
				return ({ 
					'completed': (local.total_rows() === (local.offset() + local.getLength())),
					'totalRows': local.total_rows(),
					'visibleRows': local.visibleRows.length,
					'rows': local.each(),
					'pageSize': (local.query.get('system').page_size || local.total_rows()),
					'cachedPages': queryPages.pages.length, 
					'page': current_page,
					'next': function() {
						if ((current_page * this.pageSize) < this.visibleRows) {
							current_page += 1;								
						}
						return this;
					},
					'prev': function() {
						if (current_page > 0) {
							current_page -= 1;								
						}
						return this;
					},
					'pages': function() { 
						return Math.ceil(this.visibleRows / this.pageSize); 
					},
					'lastPage': function() { 
						return queryPages.pages.length; 
					} 
				});
			};
			response.pageInfo = pageInfo;
			
			// What it does: caller supplied or callback from menus to render rows and 
			// update the browser with spinning wheel and alerts
			var nextPrev = function (arg) {
				var direction = ( (arg && typeof arg === 'string') ? arg : arg && arg.text );
				
				if (direction) {
					direction = direction.toLowerCase().split(' ');
				}
				this.query.events.trigger(this.query.get('onDisplayStart'));
				if (!direction) {
					current_chunk = 0;
					this.query.events.trigger(this.query.get('onDisplay'), this.page());
					return this;	
				} 
				if (_.arrayFound('next', direction)) {
					current_chunk += (current_chunk < queryPages.pages.length-1) ? 1 : 0;
					this.pageInfo().next();					
					this.query
						.events.trigger(this.query.get('onDisplay'), this.page(), 'onPagination');
					// if we haven't cached all the pages, and we have one more page in
					// cache before we run out, then cache another page from the server 
					if (!this.pageInfo().completed && 
						(this.pageInfo().page) === (this.pageInfo().lastPage()-1)) {
							console.log('triggering get-more-data!', this.pageInfo());
						this.page().events.trigger('get-more-data', this.page().nextkey);
					}
				} else if (_.arrayFound('previous', direction)) {
					current_chunk -= (current_chunk > 0) ? 1 : 0;
					this.pageInfo().prev();	
					this.query
						.events.trigger(this.query.get('onDisplay'), this.page(), 'onPagination');									
				}
				// trigger format the #loading and #status div area
				this.query.events.trigger(this.query.get('onDisplayEnd'));						
			};
			response.nextPrev = nextPrev;

			// updates the pages cache
			queryPages.pages.push(response);	
			// accumulates the rest of the pages for this result, if 'asynch'
			if (response.query.get('system').asynch === true && 
				queryPages.pages.length > 1) {
				response.query.events.trigger('onMoreData', response);										
			}
			return response;
		};
		queryPages.data = data;
		return data;
	};
	
	// What it does: fetches data from the server
	// NOTE: 'result' is a Result() object
	var get = function () {	
		var local = this;
		console.log('get', this.get('onResult'));
		this.db.get(this.post(), function(result) {
			console.log('got', local.get('onResult'));
			if (result.code === 200) {
				// set result and call down to nextPrev with this result and no argument
				local.result = result.nextPrev();
				console.log('trigger', local.get('onResult'));
				local.events.trigger(local.get('onResult'), result);
			} else {
				console.log('result.code', result.code);
			}			
		}, result());
		return this;						
	};
	query.server = get;

}(this));	

/*
// incremental adds keys for keyed searches
var selectKeys = function (k) {
	var local = this;
				
	if (k && k.length > 0 ) {
		k.forEach(function(key) {
			local.selected.store(key, 1);
		});	
	}
	return(_.reduce(_.map(this.selected.keys(), function (x) { 
		return x.split(','); 
		}), function (x, y) {
				x.push(y);
				return x;
			}, []));
};
query.selectKeys = selectKeys;
*/

