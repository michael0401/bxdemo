/* ===================================================
 * row.js v0.01
 * https://github.com/rranauro/boxspringjs
 * ===================================================
 * Copyright 2013 Incite Advisors, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

/*jslint newcap: false, node: true, vars: true, white: true, nomen: true  */
/*global _: true, Boxspring: true */

(function(global) {
	"use strict";

	var row = function (owner, currentRow) {		
		// Object for creating a hash out of the row for accessing and manipulating it
		var that = _.extend({}, currentRow, _.hash());
		that.columns = (owner && owner.columns) || [];
		that.keys = (owner && owner.keys) || [];
		that.visible = (owner && owner.visible) || _.hash();
		that.cell = (owner && owner.cell);

		var getKey = function (index) {
			var key = _.isArray(this && this.key) ? this.key : [ this && this.key ];
			return typeof index !== 'undefined' ? key[index] : key;
		};
		that.getKey = getKey;

		var getValue = function () {
			return typeof this.value === 'string'
				? this.value
				: _.extend({}, 
				this.doc || {}, 
				(this.doc && this.doc.resource) || {}, 
				this.value || {});
		};
		that.getValue = getValue;
		
		// add the key/values for this row to the hash;
		if (typeof that.getValue() === 'string') {
			that.update({'value': that.getValue() });
		} else {
			that.update(that.getValue());
		}
		
		// any columns not in the keys have to match by name, except for the special case when 'value' is a string
		// and not an object;
		_.difference(that.columns, that.keys).forEach(function(name, index) {
			if (!that.get(name)) {
				that.set(name, that.get('value'));
			}
		});
		
		// use position to store the key-values by name
		that.keys.forEach(function(name, index) {
			that.set(name, that.getKey(index));
		});
		
		

		// What it does: return the value of 'name' in this row
		var select = function (name) {
			return this.get(name) || (name === 'id' && this.id);
		};
		that.select = select;

		// What it does: returns true if value of 'name' equals 'value'
		var selectFor = function (name, value) {
			var selected = _.isString(this.select(name)) 
				? this.select(name).toLowerCase() 
				: this.select(name)
			, val = _.isString(value) 
				? value.toLowerCase()
				: value;			
			return (selected === val);
		};
		that.selectFor = selectFor;

		// What it does: filter the object key/value pairs against the row key/values. If all keys pass, then
		// the row passes;
		var filter = function(object) {
			var row = this
			, len = _.reduce(object, function(result, value, key) {
				if (row.select(key) === value) {
					result.push(key);
				}
				return result;
			},[]);
			return (len === _.keys(object).length);
		};
		that.filter = filter;
		return that;
	};
	global.row = row;

}(Boxspring));
