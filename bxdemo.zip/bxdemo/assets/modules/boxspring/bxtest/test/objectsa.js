if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}

var dbObject = [ 'db_name',
  'maker',
  '_design',
  '_view',
  '_update',
  'auth',
  'Boxspring',
  'createdb',
  'users',
  'doc',
  'bulk',
  'design',
  'view',
  'rows',
  'row',
  'cell',
  'Query',
  'Users',
  'VERSION',
  'create',
  'queryHTTP',
  'heartbeat',
  'session',
  'all_dbs',
  'login',
  'logout',
  'replicate',
  'use',
  '_attributes',
  '_original',
  'set',
  'store',
  'get',
  'lookup',
  'attributes',
  'find',
  'contains',
  'post',
  'getLength',
  'each',
  'remove',
  'keys',
  'first',
  'update',
  'pick',
  'restore',
  'empty',
  'headers',
  'options',
  'docinfo',
  'source',
  'url',
  'exists',
  'all_docs',
  'db_info',
  'save',
  'retrieve',
  'read',
  'getRev',
  'head',
  'delete',
  'attachment',
  'info',
  'sync',
  'urlRoot',
  'HTTP',
  'Doc',
  'uuids' ]

, docObject = dbObject
, bulkObject = docObject
, designObject = bulkObject.concat(['formats', 'types', 'views', 'updateDoc', 'extend', 'fetch'])
, viewObject = designObject.concat(['fetch', 'system', 'bind', 'emulate', 'end', 'off', 'on', 'trigger', 'unbind']);

var rowObject = [ '_attributes',
  '_original',
  'attributes',
  'set',
  'store',
  'get',
  'lookup',
  'find',
  'contains',
  'post',
  'getLength',
  'remove',
  'keys',
  'first',
  'each',
  'update',
  'pick',
  'restore',
  'empty',
  'columns',
  'visible',
  'cell',
  'getKey',
  'getValue',
  'select',
  'selectFor',
  'filter' ]
, rowsObject = [ 'columns',
  'keys',
  'displayColumns',
  'cell',
  'offset',
  'first',
  'last',
  'getRow',
  'total_rows',
  'getLength',
  'facets',
  'sortByValue',
  'range',
  'getSortColumn',
  'getDisplayColumns',
  'getSelected',
  'column2Index',
  'index2Column',
  'sortByColumn',
  'calcDisplayColumns', 
  'filter', 
  'setDisplayColumns',
  'rows' ];

var db = Maker.use()
, db2 = Maker.set({'db_name': 'regress', 'id': 'your-db', '_design': 'your-design' }).use()
, newdoc1 = db.doc('write-file-test').set({'content': Date() })
, newdoc = db.doc('sample-content').set({'content': Date() })
;

test('objects', function (t) {
	t.plan(17);
	
	t.equal(db.VERSION, '0.0.1', 'version-check');
	t.equal(db._design, '_design/my-design', 'db-options-check1');
	t.equal(db2._design, '_design/your-design', 'db-options-check2');
	t.equal(db2.db_name, 'regress', 'db-name');	
	t.equal(newdoc===newdoc1, false, 'doc-check1');	
	t.equal(newdoc.get('_id')===newdoc1.get('_id'), false, 'doc-check2');
	t.equal(typeof Maker, 'object', 'maker-function');
	t.equal(_.identical([ 'object', 'object', 'function', 'function', 'function' ],
		[typeof db, typeof db2, typeof db.doc, typeof db.design, typeof db.bulk]), true, 
		'boxspring');

	var compare = function (actual, expected, testname) {
		var intersection = _.intersection(actual, expected);

		actual = _.sortBy(actual, _.item);
		expected = _.sortBy(expected, _.item);

		if (_.identical(actual, expected)) {
			t.equal(true, true, testname);
			return ;
		} 
		t.equal(false, true, testname);
		if (_.difference(actual, intersection).length > 0) {
			console.log(_.difference(actual, intersection), 'not found in actual');		
		} else if (_.difference(expected, intersection).length > 0) {
			console.log(_.difference(expected, intersection), 'missing from expected');		
		} else if (expected.length !== actual.length) {
			console.log('Unequal length comparison', actual.length, expected.length);
		}
	}

	compare(dbObject, _.keys(db), 'createdb'); 	
	compare(docObject, _.keys(db.doc()), 'doc');
	compare(bulkObject, _.keys(db.doc('_bulk_docs')), 'bulk');
	compare(designObject, _.keys(db.design('_design/my-design')), 'design');
	compare(_.keys(db.design('_design/my-design').view('_view/my-view')), _.uniq(viewObject), 'view');
	compare(rowObject, _.keys(db.design('_design/my-design').row()), 'row');
	compare(rowsObject, _.keys(db.design('_design').rows()), 'rows'); 
	t.equal(typeof db.cell(), 'object', 'cell-object');
	t.equal(db.doc('my-doc').url(), '/regress/my-doc', 'url');

});



