#!/bin/bash

if [ $# -lt 2 ]
then
	db=''
else 
	db=/$2
fi

if [ $# -lt 1 ]
then
	COUCHDBNAME='michael'
	export COUCHDBNAME

	COUCHDBPASSWORD='abc123'
	export COUCHDBPASSWORD

	COUCHDBURL='http://localhost:5984'
	export COUCHDBURL
	echo Supply either \'local\' or \'cloudant\'
else
	echo -n "Enter your username and press [ENTER]: "
	read name
	echo -n "Enter your password and press [ENTER]: "
	read password

	if [ $1 == 'local' ]
	then
		url='http://localhost:5984'$db

	fi

	if [ $1 == 'cloudant' ]
	then
		url='https://rranauro.cloudant.com'$db
	fi
	COUCHDBNAME=$name
	export COUCHDBNAME

	COUCHDBPASSWORD=$password
	export COUCHDBPASSWORD

	COUCHDBURL=$url
	export COUCHDBURL
fi

echo Start Testing
echo JS-BASE
node test_base.js | grep 'not ok'
echo ObjectsA
node objectsa.js | grep 'not ok'
echo ObjectsB
node objectsb.js | grep 'not ok'
echo Test1
node test1a.js | grep 'not ok'
node test1b.js | grep 'not ok'
node test1c.js | grep 'not ok'
node test1d.js | grep 'not ok'
echo Test2
node test2.js | grep 'not ok'
echo Test3
node test3a.js | grep 'not ok'
node test3b.js | grep 'not ok'
node test3c.js | grep 'not ok'
echo Test4
node test4a.js | grep 'not ok'
node test4b.js | grep 'not ok'
node test4c.js | grep 'not ok'
echo Test5
node test5a.js | grep 'not ok'
node test5b.js | grep 'not ok'


