#!/bin/bash

echo -n "Enter your database selection (local/cloudant) and press [ENTER]: "
read selection
echo -n "Enter your username and press [ENTER]: "
read name
echo -n "Enter your password and press [ENTER]: "
read password

if [ $selection == 'local' ]
then
	url='http://localhost:5984'

fi

if [ $selection == 'cloudant' ]
then
	url='https://rranauro.cloudant.com'
fi
COUCHDBNAME=$name
export COUCHDBNAME

COUCHDBPASSWORD=$password
export COUCHDBPASSWORD

COUCHDBURL=$url
export COUCHDBURL


echo Start Testing
echo Base Utils
node test_base.js | grep 'not ok'
echo ObjectsA
node ./bxtest/test/objectsa.js | grep 'not ok'
echo ObjectsB
node ./bxtest/test/objectsb.js | grep 'not ok'
echo Test1
node ./bxtest/test/test1a.js | grep 'not ok'
node ./bxtest/test/test1b.js | grep 'not ok'
echo Test2
node ./bxtest/test/test2.js | grep 'not ok'
echo Test3
node ./bxtest/test/test3a.js | grep 'not ok'
node ./bxtest/test/test3b.js | grep 'not ok'
node ./bxtest/test/test3c.js | grep 'not ok'
echo Test4
node ./bxtest/test/test4a.js | grep 'not ok'
node ./bxtest/test/test4b.js | grep 'not ok'
node ./bxtest/test/test4c.js | grep 'not ok'
echo Test5
node ./bxtest/test/test5a.js | grep 'not ok'
node ./bxtest/test/test5b.js | grep 'not ok'


