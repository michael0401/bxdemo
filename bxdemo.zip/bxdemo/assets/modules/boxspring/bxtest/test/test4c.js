if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var boxspringjs = Maker.use()
, docs = _.map([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17], function(i) {
	return({'_id': 'doc' + i, 'now': Date() });
});



(function() {
	
	var pagingTests = function() {
		
		test('query-paging-tests2', function (t) {
			var pages
			, page
			, query = boxspringjs.Query(boxspringjs.view(),
				{'asynch': true, 'page-size': 1, 'cache-size': 25, 'delay': 1/10 });

			t.plan(21)
			query.on('result', function(result) {
				t.equal(result.pageInfo().pages(), 21, 'total-pages');
			});
			
			query.on('more-data', function(result) {
				t.equal(true, true, 'more-data-'+result.pageInfo().cachedPages);
			});
			
			query.on('completed', function(result) {
				t.equal(true, result.pageInfo().completed, 'result-completed');
			})
			query.fetch();
		});
	};
					
	boxspringjs
		.bulk(docs)
		.save(function(err, response) {
			if (err) {
				response.status().forEach(function(doc, index) {
					if (doc && doc.error !== 'conflict') {
						throw 'Non-conflict error: ' + index;
					}
				});
				console.log('Bulk conflicts, proceeding...');
				pagingTests();
			} else {
				pagingTests();
			}
		});
}());


