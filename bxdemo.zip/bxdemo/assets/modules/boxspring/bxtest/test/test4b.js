if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var boxspringjs = Maker.use()
, docs = _.map([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17], function(i) {
	return({'_id': 'doc' + i, 'now': Date() });
});



(function() {
	
	var moreDataTests = function(cb) {
		var rowCount
		, pages
		, query = boxspringjs.Query(boxspringjs.view(), {}, { 'type': 'Table' });

		query.system.update({'asynch': true, 'page-size': 3, 'cache-size': 50 });
		query.on('change:result', function() {
			console.log('first change event');
			var result = this.get('result');

			pages = Math.floor(result.total_rows() / 3);
			t.plan(pages+10);

			console.log(result.getLength(), 3, 'initial-result');
			console.log(query.system.get('asynch'), true, 'asynch-true');
			rowCount = result.total_rows();
		});

		var changeRegister = function () {
			console.log(query.qid, query.get('more-data').query.qid, 'changeRegister');
		}

		var eventRegister = function () {
			// remove the data from the db
			boxspringjs
				.bulk(docs)
				.remove(function(err, response) {
					if (err) {
						console.log(err, response.code);
						return ;
					}
					console.log('Dummy docs removed');
					console.log(1, 1, page.toString());								
				});
			// register the event and exit;
			cb();
			console.log(query.qid, this.get('completed').query.qid, 'eventRegister');
		}

		query.on('change:more-data', changeRegister);
		query.on('change:completed', eventRegister);
		query.fetch();
	};
	
	var pagingTests = function() {
		
		test('query-paging-tests1', function (t) {
			var pages
			, page
			, query = boxspringjs.Query(boxspringjs.view(),
				{'asynch': true, 'page-size': 1, 'cache-size': 2, 'delay': 1/10 });

			t.plan(3)
			query.on('result', function(result) {
				
				if (result.pageInfo().page === 1 && !page) {
					t.equal(result.pageInfo().pages(), 21, 'total-pages');
					result.nextPrev('next');
				} else if (result.pageInfo().page === 2) {
					t.equal(result.pageInfo().page, 2, 'next-page');
					if (!page) {
						page = 1;
						result.nextPrev('previous');
					}
				} else if (result.pageInfo().page === 1 && page === 1) {
					t.equal(true, true, 'Page-next-previous-completed');
				}
			});
			query.fetch();
		});
	};
					
	boxspringjs
		.bulk(docs)
		.save(function(err, response) {
			if (err) {
				response.status().forEach(function(doc, index) {
					if (doc && doc.error !== 'conflict') {
						throw 'Non-conflict error: ' + index;
					}
				});
				console.log('Bulk conflicts, proceeding...');
				pagingTests();
			} else {
				pagingTests();
			}
		});
}());


