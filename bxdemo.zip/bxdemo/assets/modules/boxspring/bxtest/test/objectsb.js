if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var withDefaults = Maker.set({
	'db_name': 'regress', 
	'_design': 'my-design-name', 
	'_view': 'my-index',
	'_update': 'my-update', 
	'auth': auth.auth}).use()
, noDefaults = Boxspring().set({'db_name': 'my-db'}).use();

test('defaults', function (t) {
	t.plan(15);
	
	var a, b, c, d;

	console.log('** withDefaults');
	t.equal(withDefaults.url(), '/regress', 'withDefaults');
	a = withDefaults.design();
	t.equal(a.url(), '/regress/_design/my-design-name', 'with_design');
	b = a.view();
	t.equal(b.url(), '/regress/_design/my-design-name/_view/my-index', 'with_view');
	c = withDefaults.design().updateDoc();
	t.equal(c.url(), '/regress/_design/my-design-name/_update/my-update', 'with_update');
	d = withDefaults.bulk();
	t.equal(d.url(), '/regress/_bulk_docs', 'with_bulk_docs');
	b = withDefaults.view();
	t.equal(b.url(), '/regress/_design/my-design-name/_view/my-index', 'with_no_design');

	console.log('\n** noDefaults');
	t.equal(noDefaults.url(), '/my-db', 'noDefaults');
	a = noDefaults.design();
	t.equal(a.url(), '/my-db/_design/default', 'no_design');
	b = a.view();
	t.equal(b.url(), '/my-db/_design/default/_view/default', 'no_view');
	c = a.design().updateDoc();
	t.equal(c.url(), '/my-db/_design/default/_update/default', 'no_update');

	console.log('\n** over-ride Defaults');
	
	a = withDefaults.design('_design/some-other-design');
	t.equal(a.url(), '/regress/_design/some-other-design', 'override');
	b = a.view('_view/some-other-view');
	t.equal(b.url(), '/regress/_design/some-other-design/_view/some-other-view', 'override_view');
	c = a.design('_design/some-other-design').updateDoc('_update/some-other-update');
	t.equal(c.url(), '/regress/_design/some-other-design/_update/some-other-update', 'override_update');

	console.log('\n** partial over-ride Defaults');
	a = withDefaults.design('_design/some-other-design');
	b = a.view();
	t.equal(b.url(), '/regress/_design/some-other-design/_view/my-index', 'partial_view');
	c = a.updateDoc('my-update');
	t.equal(c.url(), '/regress/_design/some-other-design/_update/my-update', 'partial_update');
	
});	



