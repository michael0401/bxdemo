if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var boxspringjs = Maker.use()
, anotherdb = Maker.set('maker', ddoc).use();

(function () {

	test('test3a', function (t) {
		t.plan(9);
		console.log('Running boxspringjs-2: 8');

		var design = anotherdb.design('_design/my-design');

		t.equal(typeof design, 'object');
		t.equal(anotherdb._design, '_design/my-design', 'design-name-test');

		var anotherdbDesignTests = function () {
			anotherdb.design().update(function(err, response) {
				t.equal(response.code, 201, 'anotherdb-design');
				anotherdb.view().fetch({}, function (err, c) {
					anotherdb.design('_design/my-design').view('_view/my-view')
					.fetch({}, function(e, n) {
						t.equal(c.getLength(), n.getLength(), 'my-view-response');
					});
				});
			});
		}


		var designTests = function () {
			var ud = design.updateDoc('_update/my-commit');
			// What this does: gets a list of documents using the built-in 'Index' view. 
			// For each document, it gets the key.id and calls the server-side 'update' using 
			// a local update handler 'my-commit'. After the last completion, it asserts the test
			// and triggers the queue-test and a 'read-back-test' to exercise the 'Index' view 
			// running in node.js and not on the server.
			design.view('_view/my-view').fetch({}, function(e, r) {

				design.view('_view/my-view').fetch({}, function(e, n) {
					t.equal(r.body.rows.length, n.body.rows.length, 'view-tests');
					design.updateDoc('_update/my-commit')
						.source({ 'random': Date.now() })
						.update('base_test_suite1', function(e, commit) {
							t.equal(commit.body.error, 'render_error', 'expect-update-fail');
							ud.source({'random': Date.now() })
							.update('base_test_suite', function(e, r) {
								t.equal(r.code, 201, 'update-handler');
								anotherdbDesignTests();								
							});
					});					
				}); 
			});		
		};

		design.login(function(err, response) {
			if (err) {
				console.log(response.body);
			}
			design.update(function(err, response) {
				t.equal(response.code, 201, 'design-saved');
				design.retrieve(function(err, res) {
					var readBack = res.body
					, designKeys = _.keys(readBack.updates).concat(_.keys(readBack.views));

					t.equal(_.difference(designKeys, 
						[ 'my-commit', 'lib', 'my-view' ]).length,0, 'design-read-back');
					designTests();
				});
			});			
		});
	});	
}());

