if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var boxspringjs = Maker.use()
, anotherdb = Maker.use()
, newdoc = boxspringjs.doc('sample-content').set({'content': Date() })
, newdoc1 = boxspringjs.doc('write-file-test').set({'content': Date() });

(function(){
	// tests to verify db.js
	test('boxspringjs-1', function (t) {

		t.plan(8);

		var verify = function (err, response) {
			if (err) {
				console.log(response && response.data || err);
			}
		};

		anotherdb.heartbeat(function(err, data) {
			verify(err, data);
			t.equal(data.code, 200, 'heartbeat');
		});

		anotherdb.session(function(err, data) {
			verify(err, data);
			t.equal(data.code, 200, 'session');
		});

		anotherdb.db_info(function(err, data) {
			verify(err, data);
			t.equal(data.code, 200, 'db_info');
		});

		anotherdb.all_dbs(function(err, data) {
			verify(err, data);
			t.equal(data.code, 200, 'all_dbs');

			// gets root name by default, then tests getting name with id provided
			t.equal(anotherdb.db_name, 'regress', 'regress-name');
			// tests the defaultView method since not defined
			t.equal(anotherdb._view, '_view/my-view', 'my-view');
			// not explicitly defined 'default'
			t.equal(anotherdb._design, '_design/my-design', 'default');
			// makes sure we return a .doc object		
			t.equal(typeof anotherdb.doc, 'function', 'function');
		});
	});
}());







