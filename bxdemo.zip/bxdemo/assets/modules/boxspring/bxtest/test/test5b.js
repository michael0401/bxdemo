if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}

thisauth = auth;
alternate = alternate;
badname = badname;
badpass = badpass;

var Admin = admin = Boxspring().set({'db_name': '_users', 
	'auth': auth }).use('http://localhost:5984');
	
// anonymous user
var user = Boxspring().set({'db_name': '_users'}).use().users('ron')
, db1 = Boxspring().set({'db_name': 'regress', 'auth': {'name': 'ron', 'password': 'ran'} }).use()
, db2 = Boxspring().set({'db_name': 'regress', 'auth': badname.auth }).use()
, db3 = Boxspring().set({'db_name': 'regress', 'auth': badpass.auth }).use()
;


test('boxspring-auth-2', function(t) {
	t.plan(17);
	
	var signUpSequence4 = function () {
		var model = new user.Users(user)
		, expected = true;
		
		model.set('auth', auth);

		model.on('change:loggedIn', function() {
			t.equal(this.get('loggedIn'), expected, 'loggedIn');
			expected = !expected;
		});
		
		model.on('change:removed', function() {
			t.equal(this.get('removed'), 200, 'changed');
		});
		
		model.on('change:error', function(source, e) {
			console.log('error', e.err);
			t.equal(0, 1, e.err);
		});
		
		model.on('change:updated', function() {
			t.equal(this.get('error'), null, 'updated');
			model.set('auth', {'name': 'couchdb', 'password': 'admin'});
			model.login();
		});
		
		model.login();
		_.wait(2, function() {
			model.logout();
		});
		
		_.wait(4, function() {
			model.set('auth', {'name': 'ron', 'password': 'ran'});
			var mydb = user.users('_users', model.get('auth').name);
	
			user.signUp(model.get('auth').password, 
						model.get('roles'), function(err, response, userDb) {
				if (err) {
					return model.error(err, response);
				}
				model.set('userDb', userDb);
				model.set('loggedIn', true);
			});
			
			//model.signup();
		});
		
		_.wait(6, function() {
			model.logout();
		});
		
		_.wait(8, function() {
			model.login();
		});
				
		_.wait(10, function() {
			model.update('ran');
		});
		
		_.wait(12, function() {
			model.remove('ron');
		});
	}


	var signUpSequence3 = function () {
		user.signUp('ran', [], function(err, response, user) {
			t.equal(err, null,'signUp-3');
			// use the created/logged in account to change the password
			user.users('ron').update('run', [], function(err, response) {
				t.equal(err, null, 'update-user-3');
				// remove using the admin account
				admin.users('ron').remove(function(err, response) {
					t.equal(response.code, 200, 'delete-updated-user-3');
					// confirm the login fails
					user.login(function(err, response) {
						t.equal(response.code, 401, 'login-deleted-3');
						signUpSequence4();
					});
				});
			});
		});
	};

	// test that a duplicate user name will fail
	var signUpSequence2 = function () {
		user.signUp('ran', [], function(err, r) {
			t.equal(err, null, 'signUp-2');
			if (err) {
				console.log(r.data);
				throw '';
			}
			user.signUp('ran', [], function(err, response) {
				t.equal(response.code, 409, 'signUp-conflict-2');
				admin.users('ron').remove(function(err, response) {
					t.equal(response.code, 200, 'user-deleted-2');
					if (response.code === 200) {
						signUpSequence3();						
					}
				});
			});		
		});
	};
		
	// test that a user name is created, and deleted.	
	var signUpSequence1 = function () {
		user.signUp('ran', [], function(err, response, newUser) {
			t.equal(err, null, 'signUp-1');
			if (err) {
				console.log(response.data, user.auth);
			}
			newUser.users('ron').remove(function(err, response) {
				if (err) {
					t.equal(response.code, 404, 'expect-remove-fail');
					// expect to fail, user can't remove their own
					admin.users('ron').remove(function(err, response) {
						t.equal(response.code, 200, 'user-deleted-1');
						if (response.code === 200) {
							signUpSequence2();					
						}
					});
				} else {
					t.equal(response.code, 404, 'expect-remove-fail');
					signUpSequence2();
				}
			});

		});		
	};
	
	admin.login(function(e, r) {
		admin.users('ron', admin).fetch(function(err, res) {
			// if existing, remove it
			if (!err) {
				admin.users('ron', admin).remove(function(err, res) {
					if (err) {
						return console.log('Unable to remove user, aborting...', err);
					}
					console.log('Removed user before starting...');
					signUpSequence1();
				});
			} else {
				// otherwise, proceed
				console.log('Nothing to remove before starting...');
				signUpSequence1();
			}
		});		
	});
});

