if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var boxspringjs = Maker.use()
, doc1 = boxspringjs.doc('first').set({'content': 'aw'})
, doc2 = boxspringjs.doc('second').set('content', 'shucks')
, doc3 = boxspringjs.doc('third').set('content', 'goods')
;

(function () {

	test('bulk-tests', function (t) {
		t.plan(10);

		var bulkPushTest = function () {
			var bulk = boxspringjs.bulk()
			.push(_.omit(doc1.post(), '_url'))
			.push(doc2);
			t.equal(bulk.getLength(), 2, 'bulk-getLength');
			bulk.save(function(err, result) {
				t.equal(result.code, 201, 'bulk-push-save');
				bulk.remove(function(err, data) {
					t.equal(data.body[0].ok, result.body[0].ok, 'bulk-push-remove');
				});
			});	
		}
		, bulk = boxspringjs.bulk([ doc1, _.omit(doc2.post(), '_url') ]);
		t.equal(typeof bulk, 'object', 'is-object');
		t.equal(typeof bulk.save, 'function', 'is-function');
		t.equal(typeof bulk.bulk, 'function','is-another-object-1');
		// bulk tests
		bulk.save(function(err, result) {
			t.equal(result.code, 201, 'bulk-save');
			if (result.code === 201) {
				result.status().forEach(function(status) {
					t.equal(status, false, 'bulk-save-status');
				})
				bulk.remove(function(err, data) {
						t.equal(data.body[0].ok, result.body[0].ok, 'bulk-remove');
						bulkPushTest();
				});	
			}
		});	
	});	
}());