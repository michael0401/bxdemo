if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}

var boxspringjs = Maker.use()
, newdoc = boxspringjs.doc('sample-content').set({'content': Date() })
, newdoc1 = boxspringjs.doc('write-file-test').set({'content': Date() });

(function(){
	// reading view indexes
	test('boxspringjs-3', function (t) {

		t.plan(4);

		// save and expect to fail
		newdoc1.save(function(err, response) {
			t.equal(response.code, 409, 'save-fail');
			// update should work
			newdoc1.update(function(err, update) {
				//console.log('update response', newdoc1.docRev(), update.header.etag, update.code);
				t.equal(update.code, 201, 'newdoc1 update');
				// get all docs using map views on the server (default)
				boxspringjs
					.view('_all_docs')
					.fetch({}, function(err, couch) {
					t.equal(couch.code, 200, 'all_docs');

					// get all docs using map views FUTURE running in node
					boxspringjs
						.view('_view/_all_docs')
						.fetch({}, function(err, node) {
						var found;
						_.each(node.body.rows, function(d) {
							var found;
							_.each(couch.body.rows, function(c) {
								found = (c.id === d.id && d.id);
							});
						});
						t.equal(typeof found, 'undefined', 'get-compared');
					});
				});
			});
		});
	});	
}());


	






