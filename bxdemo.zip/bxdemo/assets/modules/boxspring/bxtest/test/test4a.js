if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var boxspringjs = Maker.use('127.0.0.1')
, anotherdb = Maker.use('127.0.0.1')
, docs = _.map([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17], function(i) {
	return({'_id': 'doc' + i, 'now': Date() });
});


(function() {
	test('query-smoke-tests', function (t) {
		t.plan(9);
		
		var view = anotherdb.view() 
		, query = anotherdb.Query(view)
		, query2 = anotherdb.Query(view);
			
		// smoke test: make sure we have two different objects and attributes are set up
		t.equal(query.get('reduce') === query2.get('reduce'), true, 'query-create-1');
		t.equal(query === query2, false, 'query-create-2');
		// smoke tests to confirm the object is set up
		t.equal(query.get('reduce'), false);
		t.equal(query.system.get('asynch'), false);
		// try changing the value of one of the parameters
		query.set('display', true);
		// confirm the change
		t.equal(query.get('display'), true);
		// change a system parameter
		query.system.set('asynch', true);
		t.equal(query.system.get('asynch'), true);
		
		// verify two different event contexts
		query.on('try', function(arg) {
			t.equal(arg, 'query', 'event-create-1');
		});
		
		query2.on('try', function(arg) {
			t.equal(arg, 'query2', 'event-create-2');
		});
		
		query.trigger('try', 'query');
		query2.trigger('try', 'query2');
			
		// event when the server has data			
		query.on('change:result', function() {
			var response = this.get('result');
			t.equal(response.total_rows(), response.getLength(), 'smoke-test-result');
		});
		// query the server
		query.fetch({
			'reduce': false,
			'limit': 500 });
	});	
}());



