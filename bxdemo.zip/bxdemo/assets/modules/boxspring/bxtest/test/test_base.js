if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} 
/* 
_.toInt = toInt;
_.trim = trim;
_.initialCaps = initialCaps;
_.enclose = enclose;
_.args = args;
_.arrayFind = arrayFind;
_.arrayFound = arrayFound;
_.arrayCompare = arrayCompare;
_.arrayMap = arrayMap;
_.arrayIdentical = arrayIdentical;
_.arrayBfind = arrayBfind;
_.forceToArray = forceToArray;
_.reverse = reverse;
_.coerce = coerce;
_.item = item;
_.filterNonAscii = filterNonAscii;
_.select = select;
_.clean = clean;
_.pfetch = pfetch;
_.fetch = fetch;
_.hfetch = hfetch;
_.walk = walk;
_.buildHTML = buildHTML;
_.wait = wait;
*/

// Documentation: https://npmjs.org/package/tape
test('base-utils-tests', function (t) {
	var enclose
	, obj = {
		'var1': {
			'var2': {
				'var3': 'var3-value'
			},
			'var4': 'var4-value',
			'var6': 'another-value'
		},
		'var5': Date()
	}
	, tmp = []
	;
	
    t.plan(27);

	t.equal(_.toInt("-5")+_.toInt("4")+_.toInt(1), 0, "check toInt");
	t.equal(_.trim(' hello      js-base;  '), 'hello js-base;', "check trim");
	t.equal(_.initialCaps('i am a red fox'), 'I am a red fox', "check initialCaps");
	enclose = _.enclose(function(end) {
		return end;
	}, 'yes!');
	t.equal(enclose(), 'yes!', "check enclose");
	t.equal(_.compare(('a', 'b'), ['a','b']),true, "check compare");
	t.equal(_.compare(_.args('a','b'), ['a','b']),true, "check args");
	t.equal((_.found(['a', 'b', 'item', 'd'], 'item')===true)&&(_.found(['a', 'b', 'item', 'd'], 'item2')===false), true, "check found");

	t.equal((_.identical([1, 2, 3], [1, 2, 3])===true)&&(_.identical([1, 2, 3], [1, 3])===false), true, "check identical");
	t.equal((_.compare(_.bfind([1, 2, 3, 4], 2),[2])=== true)&&(_.bfind([1, 2, 3, 4], 7) === null), true, "check bfind");
	t.equal(_.compare(_.forceToArray(2,3,4), [2,3,4]), true, "check forceToArray");
	t.equal(_.compare([4, 3, 2, 1], _.reverse([1, 2, 3, 4])), true , "check reverse");
	
	t.equal( _.isString(_.coerce('string', 0)) &&
		_.isNumber(_.coerce('number',"1")) &&
		_.isString(_.coerce('string')) &&
		_.isNumber(_.coerce('number')) &&
		_.isDate(_.coerce('date', new Date())) && 
		_.isDate(_.coerce('date', 'junk')) &&
		_.isBoolean(_.coerce('boolean', true)) &&
		_.isBoolean(_.coerce('boolean', 'false')) &&
		_.coerce('boolean', 'true'), true, "check coerce");
		
	t.equal(_.filterNonAscii("1\0 2\0 3\0 4"), "1 2 3 4", "check filterNonAscii");
	
	t.equal(_.compare(_.map([1, 2, 3], _.item), [1, 2, 3]), true, "check item");
	
	t.equal(_.compare(
		_.keys(_.select(obj, ['var1', 'var5'])), _.keys(_.pick(obj, 'var1', 'var5'))), true, "check select");
		
	t.equal(_.difference(
		_.values(_.clean({'a': 'yes', 'b': undefined, 'c': 'again!', 'd': undefined })),
			['yes', 'again!']).length, 0, "check clean 1");
	t.equal(_.difference(
		_.values(_.clean({'a': 'yes', 'b': undefined, 'c': 'again!', 'd': undefined }, 'yes')),
		[undefined, undefined, 'again!']).length, 0, "check clean 2");	
	
	t.equal(_.pfetch(obj, 'var4'), "var4-value", "check pfetch");
	
	t.equal((_.fetch({'a':1, 'b':2, 'item': 3}, 'item')===3)&&(_.fetch(['a', 'b', 'item', 'd'], 'item')===2), true, "check fetch 1");
	t.equal(_.keys(_.fetch(obj, ['varx', 'var2']))[0], 'var3', "check fetch 2");
	t.equal(_.fetch(obj, 'varx', 'var6')==='another-value', true, "check fetch 3");
		
	['var1/var6', 'var1/var2/var3', '/var1/var5', 'var6'].forEach(function(path) {
		tmp.push(_.hfetch(obj, path));
	});
	console.log("******",tmp);
	t.equal(_.identical(tmp, [ 'another-value', 'var3-value', undefined, 'another-value' ]), true, "check hfetch");

	tmp = [];

	_.walk(obj, function(item, name) {
		tmp.push(name);
	});
	t.equal(_.difference(tmp, ['var1','var2','var3','var4','var6','var5']).length,0, "check walk");
	t.equal(_.buildHTML('div', 'yes!', {'id': '123'}), '<div id="123">yes!</div>', "check buildHTML 1");	
	t.equal(_.buildHTML('div', {'id': '123'}), '<div id="123"/>', "check buildHTML 2");	
	t.equal(_.buildHTML('div', 'yes!'), '<div>yes!</div>', "check buildHTML 3");
	
	_.wait(1, function(){
		
		t.equal(1, 1, "check wait");
	});

});