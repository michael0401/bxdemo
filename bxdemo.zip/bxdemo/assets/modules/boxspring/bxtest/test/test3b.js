if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var boxspringjs = Maker.use()
, anotherdb = Maker.set('maker', ddoc).use();
	
(function() {
	test('row-tests', function (t) {
		t.plan(15);
		console.log('Running row-tests: 17');

		anotherdb.view().fetch({}, function(err, response) {
			if (err) {
				console.log('row-tests(): Fetch failed - ' + response.body);
			}
			var first = response.first()
			, selected
			, selected1
			, selected2
			, cell = response.cell;
						
			t.equal(_.identical(response.body.rows[0].columns, 
									['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]), true);
			t.equal(first.select('id'), first.getKey(0));
			t.equal(first.getValue().junk, first.select('junk'));
//			t.equal(_.identical(response.visible.setValues(), 
//									[ 'id', 'content', 'junk' ]), true);
			selected1 = _.reduce(response.rows(), function(result, row) {
				if (row.selectFor('content', 'shucks')) {
					result.push(row.select('id'));
				}
				return result;
			}, []);
			selected2 = _.reduce(response.rows(), function(result, row) {
				if (row.select('content') === 'shucks') {
					result.push(row.select('id'));
				}
				return result;
			}, []);
			t.equal(_.identical(selected1, selected2), true);
			selected2 = _.reduce(response.rows(), function(result, row) {
				if (row.filter({'content': 'shucks'})) {
					result.push(row.select('id'));
				}
				return result;
			}, []);
			t.equal(_.identical(selected1, selected2), true);				
			t.equal(cell.getType('id'), 'string');
			t.equal(cell.hasType('id'), true);
			t.equal(cell.hasType(cell.builtInColumns.get('junk')), false);
			t.equal(cell.columnWidth(cell.builtInColumns.get('id')), 1);
			
			// format the cell and strip off the 'formatted: ' to make sure the cell formatted
			// the value and put it in the format field.
			selected = cell.newCell('id', first.select('id')).format.replace('formatted: ', '');
			t.equal(selected, first.select('id'));
			t.equal(cell.newCell('id', first.select('id')).type, 'string');
			// do the same as above for a field that has no formatting
			selected = cell.newCell('content', first.select('content'));
			t.equal(selected.name, 'content');
			t.equal(selected.value, 'some data needed for testing');
			t.equal(selected.type, 'string');
			t.equal(typeof selected.format, 'undefined');
		});
	});
}());

