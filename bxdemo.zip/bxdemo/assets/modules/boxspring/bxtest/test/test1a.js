if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}

var boxspringjs = Maker.use()
, newdoc = boxspringjs.doc('sample-content').docinfo({'content': Date() })
, newdoc1 = boxspringjs.doc('write-file-test').docinfo({'content': Date() });

(function() {
	// tests to verify db save/remove
	test('boxspring-create-db', function(t) {

		var mydb = Boxspring().set({'db_name': 'phantomdb', 'auth': auth }).use();

		t.plan(1);

		var create = function(db) {
			db.doc().save(function(err, response) {
				if (err) {
					console.log('could not create database - ', db.db_name, response);
					throw err;
				} else {
					console.log(db.db_name, 'successfully created.');
					db.db_info(function(err, response) {
						t.equal(response.body.db_name, 'phantomdb', 'database-created');					
					});
				}
			});
		}
		mydb.login(function(err, result){
			if(err){
				console.log("wrong username or password");
			}
			else{
				mydb.db_info(function(err, response) {
					if (err) {
						create(mydb);
					} else {
						console.log('database already exists, removing...');
						mydb.doc().remove(function(err, response) {
							if (err) {
								console.log('unable to remove - ', mydb.db_name, response.body);
							} else {
								create(mydb);
							}
						});
					}
				});
			}
			
		});
		
	});
}());







