if (typeof module !== 'undefined' && module.exports) {
            
    require('../index');
    var test = require('tape');
} else{
	
	Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

	ddoc = function () {
		return {
			"updates": {
				"my-commit": function (doc, req) {
					doc['last-updated'] = Date();
					doc.size = JSON.stringify(doc).length;
					doc.junk = 'another-try';
					return [doc, JSON.stringify(doc) ];
				}
			},
			'types': {
				'id': ['string', 1],
				'rev': ['string', 1],
				'doc': ['object', 4],
				'content': ['string', 2],
				'more-content': ['string', 2]			
			},
			"views": {
				'lib': {
					'formats': function() {
						var formatter = function(name) {
							return 'formatted: ' + name;
						}
						return({
							'id': formatter,
							'rev': formatter
						});
					}
				},
				'my-view': {
					'map': function (doc) {
						if (doc && doc._id) {
							emit(doc._id, doc);
						}
					},
					'header': {
						'sortColumn': 'doc',
						'keys': ['id'],
						'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
					}
				}
			}
		};
	};
}
var boxspringjs = Maker.use()
, anotherdb = Maker.set('maker', ddoc).use();

(function() {
	test('rows-tests', function (t) {
		t.plan(19);
		console.log('Running rows-tests: 23');
		
		anotherdb.view().fetch({}, function(err, response) {
			if (err) {
				console.log('row-tests(): Fetch failed - ' + response.body);
			}
			
			t.equal((response.rows()).length, response.body.rows.length);
			t.equal(response.column2Index('doc'), 1);
			t.equal(response.column2Index('dfdfaf'), 0);
			t.equal(response.getSortColumn(), 'doc');
			t.equal(_.identical(response.getDisplayColumns(), ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]), true);
			t.equal(_.identical(response.getDisplayColumns(['doc']), ['doc']), true);
			t.equal(response.index2Column(0), 'doc');
			t.equal(response.index2Column(1), 'doc');
			response.getDisplayColumns(['_id', 'doc']);
			t.equal(response.index2Column(0), '_id');
			t.equal(response.index2Column(1), 'doc');
			// reset the visible rows for this next test
//			response.visible.restore();
			// set them and test them
//			t.equal(_.identical(response
//							.visible.setValues({'_id': true, 'doc': false }), ['_id','doc']), true, 'set-values');
//			t.equal(response.visible.getSortColumn(), 1);
//			response.visible.restore();
//			t.equal(_.identical(response.visible.setValues(), []), true, 'set-values-restored');
//			t.equal(response.visible.getSortColumn(), 0, 'visible-sort-column');
			t.equal(_.identical(response.sortByColumn().getDisplayColumns(), ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]), true);
			t.equal(_.identical(response.sortByColumn(true).getDisplayColumns(), [ 'junk', 'rev', 'more-content', 'content', 'doc', 'id' ]), true);
			t.equal(response.offset(), 0);
			t.equal(response.total_rows(), response.getLength());
			t.equal(response.facets('id').length, response.getLength());
			t.equal(response.facets('content').length, 2);
			t.equal(response.facets('find-nothing').length, 0);
			t.equal(_.identical(response.range().start, 
					[ response.body.rows[0].key ]), true, 'start-key');
			t.equal(_.identical(response.range().end, [ response.last().key ]), true, 'last-key');				
		});
	});
}());

