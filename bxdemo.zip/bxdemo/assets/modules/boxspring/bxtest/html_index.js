module_count=0;

test = function(module, callback){
	
	module_count++;
	var template = _.template($("#module_template").html(), {module_num: module_count, module_name: module});
	$("#result-window").append(template);
	
	var test_object = {};
	test_object.module_count = module_count;
	test_object.test_count = 1;
	test_object.equal = function(value1, value2, test){
		var template = _.template($("#test_template").html(), {test_num: test_object.test_count, test_name: test});
		$("#table"+test_object.module_count).append(template);
		if(value1===value2){
			$("#table"+test_object.module_count).find("#test"+test_object.test_count).find(".status").html("true");
		}
		else{
			$("#table"+test_object.module_count).find("#test"+test_object.test_count).find(".status").html("false");
		}
		test_object.test_count++;
	};	
	test_object.plan = function(num){};	
	callback(test_object);
};

require = function(string){};

auth = {'name': '', 'password': ''};
alternate = {'name': auth.name+'bad', 'password': auth.password };
badname = {'name': auth.name+'bad', 'password': auth.password };
badpass = {'name': auth.name, 'password': auth.password+'bad' };

url = 'http://127.0.0.1:5984';
Maker = Boxspring().set({'db_name': 'regress', '_design': 'my-design', '_view': 'my-view', 'auth': auth });

ddoc = function () {
	return {
		"updates": {
			"my-commit": function (doc, req) {
				doc['last-updated'] = Date();
				doc.size = JSON.stringify(doc).length;
				doc.junk = 'another-try';
				return [doc, JSON.stringify(doc) ];
			}
		},
		'types': {
			'id': ['string', 1],
			'rev': ['string', 1],
			'doc': ['object', 4],
			'content': ['string', 2],
			'more-content': ['string', 2]			
		},
		"views": {
			'lib': {
				'formats': function() {
					var formatter = function(name) {
						return 'formatted: ' + name;
					}
					return({
						'id': formatter,
						'rev': formatter
					});
				}
			},
			'my-view': {
				'map': function (doc) {
					if (doc && doc._id) {
						emit(doc._id, doc);
					}
				},
				'header': {
					'sortColumn': 'doc',
					'keys': ['id'],
					'columns': ['id', 'doc', 'content', 'more-content', 'rev', 'junk' ]
				}
			}
		}
	};
};

function loadJS(file) {
    // DOM: Create the script element
    var jsElm = document.createElement("script");
    // set the type attribute
    jsElm.type = "application/javascript";
    // make the script element load file
    jsElm.src = file;
    // finally insert the element to the body element in order to load the script
    document.body.appendChild(jsElm);
}
$("#input-window").find(".reset-button").click(function(){
	location.reload();
});

$("#input-window").find(".test-button").click(function(){
	
	auth.name="michael";
	auth.password="abc123";
	
	$(this).hide();
	$("#input-window").find(".reset-button").show();
	$("#result-window").show();
	loadJS("./test/test_base.js");
	loadJS("./test/test4a.js");
	loadJS("./test/test4b.js");
	loadJS("./test/test4c.js");
	loadJS("./test/objectsa.js");
	loadJS("./test/objectsb.js");
	loadJS("./test/test1a.js");
	loadJS("./test/test1b.js");
	loadJS("./test/test1c.js");
	loadJS("./test/test1d.js");
	loadJS("./test/test2.js");
	loadJS("./test/test3a.js");
	loadJS("./test/test3b.js");
	loadJS("./test/test3c.js");
	loadJS("./test/test5a.js");
	loadJS("./test/test5b.js");
	
	
});