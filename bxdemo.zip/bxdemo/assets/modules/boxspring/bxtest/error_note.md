##How to run tests on node.js and browser.
* Node.js
	1. go to into folder "test"
	2. type in command "./run.sh local"
	3. type in couchDB username and password

* Browser
	1. erica push the bxtest folder to couchDB
	2. copy the returned url to the broswer

##BoxspringJS Error Note
1. objectsa.js - line 224 for node.js and broswer

  code:

      compare(_.keys(db.design('_design/my-design').view('_view/my-view')), _.uniq(viewObject), 'view');

  error:

      [ 'listenTo', 'listenToOnce', 'once', 'stopListening' ] 'not found in actual'

2.  test2.js - line 88 for node.js

  code:

	bulk.remove(function(err, data) {
		t.equal(data.body[0].ok, result.body[0].ok, 'bulk-remove');
		bulkPushTest();
	});	
    
  error:

    when run in node.js , bulk.remove() only remove the last doc in bulk
	  
3. test3a.js line 98 for node.js and broswer

  code:

    ud.source({'random': Date.now() })
    .update('base_test_suite', function(e, r) {
	t.equal(r.code, 201, 'update-handler');
	anotherdbDesignTests();								
    });
    
  error:

    expected: 201
    actual:   500

4. test3b.js - line 75 for node.js and broswer

  code:

    t.equal(first.getValue().junk, first.select('junk'));
  error:

    expected: false
    actual:   
	

5. test3b.js - line 111 for node.js and broswer

  code:

    t.equal(selected.value, 'some data needed for testing');
    
  error:

    expected: "some data needed for testing"
    actual:   ""

6. test4a.js - line 73 for node.js and browser

  code:

    t.equal(query.get('reduce'), false);
    
  error:

    expected: false
    actual:  undefined

8. test4b.js - line 119 only for node.js

  code:

    if (result.pageInfo().page === 1 && !page) {
	t.equal(result.pageInfo().pages(), 21, 'total-pages');
	result.nextPrev('next');
    }
	
  error:

    expected: 21
    actual:   20

9. test4c.js - line 73 only for node.js

  code:

    query.on('result', function(result) {
	t.equal(result.pageInfo().pages(), 21, 'total-pages');
    });
	
  error:

    expected: 21
    actual:   20

10. test4b.js - line 194 

  code:
  
	newUser.users('ron').remove(function(err, response) {
		...
		});
	
  error:
  
	newUser somehow can remove itself.

11. test4b.js - line 105

  code:
  
	model.signup() 
	
  error:
  
	It is forbidden-403
	
12. test4b.js - line 134

  code:
  
	model.remove('ron')
	
  error:
  
	It is unauthorized-401
	
